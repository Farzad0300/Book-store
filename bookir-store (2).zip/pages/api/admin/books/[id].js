import { requireAdmin } from "../../../../lib/adminAuth";
import { getBook, upsertBook, deleteBook } from "../../../../lib/store";

export default async function handler(req, res) {
  const auth = requireAdmin(req);
  if (!auth.ok) return res.status(401).json({ error: "دسترسی غیرمجاز" });

  const { id } = req.query;

  if (req.method === "PUT") {
    const existing = await getBook(id);
    if (!existing) return res.status(404).json({ error: "کتاب پیدا نشد" });

    const body = req.body || {};
    const updated = await upsertBook({
      ...existing,
      title: body.title ?? existing.title,
      author: body.author ?? existing.author,
      price: body.price !== undefined ? Number(body.price) : existing.price,
      category: body.category ?? existing.category,
      description: body.description ?? existing.description,
      cover: body.cover ?? existing.cover,
      featured: body.featured !== undefined ? Boolean(body.featured) : existing.featured,
      published: body.published !== undefined ? Boolean(body.published) : existing.published,
      fileContent: body.fileContent ?? existing.fileContent
    });

    return res.status(200).json(updated);
  }

  if (req.method === "DELETE") {
    const existing = await getBook(id);
    if (!existing) return res.status(404).json({ error: "کتاب پیدا نشد" });

    await deleteBook(id);
    return res.status(200).json({ ok: true });
  }

  return res.status(405).json({ error: "Method not allowed" });
}
