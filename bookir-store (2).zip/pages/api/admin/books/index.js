import { requireAdmin } from "../../../../lib/adminAuth";
import { getAllBooks, upsertBook } from "../../../../lib/store";

export default async function handler(req, res) {
  const auth = requireAdmin(req);
  if (!auth.ok) return res.status(401).json({ error: "دسترسی غیرمجاز" });

  if (req.method === "GET") {
    const books = await getAllBooks();
    return res.status(200).json(books);
  }

  if (req.method === "POST") {
    const book = req.body || {};

    if (!book.id || !book.title || !book.author) {
      return res.status(400).json({ error: "شناسه، عنوان و نویسنده الزامی است" });
    }

    const existing = (await getAllBooks()).find((b) => b.id === book.id);
    if (existing) {
      return res.status(409).json({ error: "کتابی با این شناسه از قبل وجود دارد" });
    }

    const saved = await upsertBook({
      id: String(book.id),
      title: String(book.title),
      author: String(book.author),
      price: Number(book.price) || 0,
      category: book.category || "novel",
      description: book.description || "",
      cover: book.cover || "/covers/scottish-novel-1.svg",
      featured: Boolean(book.featured),
      published: Boolean(book.published),
      fileContent: book.fileContent || ""
    });

    return res.status(201).json(saved);
  }

  return res.status(405).json({ error: "Method not allowed" });
}
