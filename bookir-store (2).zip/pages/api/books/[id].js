import { getBook, publicFields } from "../../../lib/store";

export default async function handler(req, res) {
  const { id } = req.query;
  const book = await getBook(id);

  if (!book) return res.status(404).json({ error: "کتاب پیدا نشد" });

  return res.status(200).json(publicFields(book));
}
