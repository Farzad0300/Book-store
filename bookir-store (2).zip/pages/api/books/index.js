import { getAllBooks, publicFields } from "../../../lib/store";

export default async function handler(req, res) {
  const books = await getAllBooks();
  return res.status(200).json(books.map(publicFields));
}
