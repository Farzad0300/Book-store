import { getAllBooks, publicFields } from "../lib/store";
import BookCard from "../components/BookCard";

export async function getServerSideProps() {
  const books = await getAllBooks();
  return { props: { books: books.map(publicFields) } };
}

export default function Store({ books }) {
  return (
    <div className="section">
      <div className="section-head">
        <h1>فروشگاه کتاب الکترونیک</h1>
      </div>
      <div className="grid">
        {books.map((b) => (
          <BookCard key={b.id} book={b} />
        ))}
      </div>
    </div>
  );
}
