import Link from "next/link";
import { getAllBooks, publicFields } from "../lib/store";
import BookCard from "../components/BookCard";

export async function getServerSideProps() {
  const books = await getAllBooks();
  return { props: { books: books.map(publicFields) } };
}

export default function Home({ books }) {
  const featured = books.filter((b) => b.published && b.featured);
  const soon = books.filter((b) => !b.published);

  return (
    <div>
      <section className="hero">
        <span className="eyebrow">فروشگاه کتاب الکترونیک</span>
        <h1>کتاب‌های الکترونیک با حال و هوای تاریک و سینمایی</h1>
        <p>کتابخانه شب، جایی برای رمان‌ها و کتاب‌های دیجیتال توست.</p>
        <Link href="/store" className="btn btn-gold">ورود به فروشگاه</Link>
      </section>

      {soon.length > 0 && (
        <section className="section">
          <div className="section-head">
            <h2>به‌زودی</h2>
            <span className="tag">در دست انتشار</span>
          </div>
          {soon.map((b) => (
            <div className="soon-spotlight" key={b.id}>
              <Link href={`/book/${b.id}`} className="book-cover-link">
                <img src={b.cover} alt={`جلد کتاب ${b.title}`} className="book-cover" />
                <span className="badge badge-soon">به‌زودی</span>
              </Link>
              <div>
                <h3>{b.title}</h3>
                <div className="author">نوشته‌ی {b.author} — رمان</div>
                <p className="desc">{b.description}</p>
              </div>
            </div>
          ))}
        </section>
      )}

      {featured.length > 0 && (
        <section className="section">
          <div className="section-head">
            <h2>کتاب‌های ویژه</h2>
          </div>
          <div className="grid">
            {featured.map((b) => (
              <BookCard key={b.id} book={b} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
